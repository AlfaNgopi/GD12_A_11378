/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package gd12_a_11378_1;

/**
 *
 * @author ASUS
 */
public interface IComposite {
    public static StringBuffer space = new StringBuffer();
    
    public void showData();
}
